package com.nothing.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.SpannableString
import android.text.Spanned
import android.text.TextUtils
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

data class AppItem(val label: String, val pkg: String, val cls: String, val icon: Drawable)

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var root: FrameLayout
    private lateinit var home: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var grid: GridView
    private lateinit var search: EditText
    private lateinit var dock: LinearLayout
    private lateinit var dateView: TextView
    private lateinit var batteryView: TextView
    private lateinit var clock: DotClockView
    private lateinit var adapter: AppAdapter

    private var apps: List<AppItem> = emptyList()
    private var filtered: List<AppItem> = emptyList()
    private var drawerOpen = false
    private val handler = Handler(Looper.getMainLooper())
    private val nothingRed = Color.parseColor("#D71921")

    private val ticker = object : Runnable {
        override fun run() {
            updateHome()
            handler.postDelayed(this, 1000)
        }
    }

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            loadApps()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun mono() = prefs.getBoolean("mono", true)
    private fun wall() = prefs.getBoolean("wall", false)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("nothing_launcher", MODE_PRIVATE)

        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN

        root = FrameLayout(this)
        root.setOnApplyWindowInsetsListener { v, ins ->
            v.setPadding(0, ins.systemWindowInsetTop, 0, 0)
            ins
        }

        buildHome()
        buildDrawer()
        root.addView(home, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(drawer, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)
        applyBg()

        loadApps()

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(pkgReceiver, f, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(pkgReceiver, f)
        }
    }

    // ---------- UI ----------

    private fun buildHome() {
        home = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(20))
        }

        home.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))

        clock = DotClockView(this)
        home.addView(clock, LinearLayout.LayoutParams(MATCH, WRAP))

        dateView = TextView(this).apply {
            setTextColor(Color.WHITE)
            typeface = Typeface.MONOSPACE
            textSize = 16f
            letterSpacing = 0.15f
            setPadding(0, dp(28), 0, 0)
        }
        home.addView(dateView, LinearLayout.LayoutParams(WRAP, WRAP))

        batteryView = TextView(this).apply {
            setTextColor(Color.parseColor("#8A8A8A"))
            typeface = Typeface.MONOSPACE
            textSize = 13f
            setPadding(0, dp(6), 0, 0)
        }
        home.addView(batteryView, LinearLayout.LayoutParams(WRAP, WRAP))

        home.addView(View(this), LinearLayout.LayoutParams(1, 0, 2f))

        val hint = TextView(this).apply {
            text = "▲"
            setTextColor(Color.parseColor("#6A6A6A"))
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(8), dp(24), dp(14))
            setOnClickListener { openDrawer() }
        }
        home.addView(hint, LinearLayout.LayoutParams(WRAP, WRAP).apply {
            gravity = Gravity.CENTER_HORIZONTAL
        })

        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(10), dp(8), dp(10))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#CC111111"))
                cornerRadius = dp(32).toFloat()
            }
        }
        home.addView(dock, LinearLayout.LayoutParams(WRAP, WRAP).apply {
            gravity = Gravity.CENTER_HORIZONTAL
        })

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (vy < -800) {
                    openDrawer()
                    return true
                }
                return false
            }

            override fun onLongPress(e: MotionEvent) {
                homeMenu()
            }
        })
        home.setOnTouchListener { _, e ->
            gd.onTouchEvent(e)
            true
        }
    }

    private fun buildDrawer() {
        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F2000000"))
            setPadding(dp(16), dp(12), dp(16), dp(8))
            visibility = View.GONE
            isClickable = true
        }

        val handle = View(this).apply {
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#444444"))
                cornerRadius = dp(2).toFloat()
            }
        }
        drawer.addView(handle, LinearLayout.LayoutParams(dp(40), dp(4)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(12)
        })

        search = EditText(this).apply {
            hint = "ПОИСК"
            setHintTextColor(Color.parseColor("#6A6A6A"))
            setTextColor(Color.WHITE)
            typeface = Typeface.MONOSPACE
            textSize = 14f
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_DONE
            setPadding(dp(20), dp(12), dp(20), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1A1A1A"))
                cornerRadius = dp(30).toFloat()
            }
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                filter(s?.toString() ?: "")
            }
        })
        search.setOnEditorActionListener { _, _, _ ->
            if (filtered.isNotEmpty()) launch(filtered[0])
            true
        }
        drawer.addView(search, LinearLayout.LayoutParams(MATCH, WRAP).apply {
            bottomMargin = dp(12)
        })

        grid = GridView(this).apply {
            numColumns = 4
            verticalSpacing = dp(8)
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            setSelector(ColorDrawable(Color.TRANSPARENT))
        }
        adapter = AppAdapter()
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, pos, _ -> launch(filtered[pos]) }
        grid.setOnItemLongClickListener { _, _, pos, _ ->
            appMenu(filtered[pos])
            true
        }
        val gd2 = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (vy > 1800 && grid.firstVisiblePosition == 0 && (grid.getChildAt(0)?.top ?: 0) >= 0) {
                    closeDrawer()
                }
                return false
            }
        })
        grid.setOnTouchListener { _, e ->
            gd2.onTouchEvent(e)
            false
        }
        drawer.addView(grid, LinearLayout.LayoutParams(MATCH, 0, 1f))
    }

    private fun applyBg() {
        root.setBackgroundColor(if (wall()) Color.parseColor("#55000000") else Color.BLACK)
    }

    // ---------- Drawer ----------

    private fun openDrawer() {
        if (drawerOpen) return
        drawerOpen = true
        drawer.translationY = resources.displayMetrics.heightPixels.toFloat()
        drawer.visibility = View.VISIBLE
        drawer.animate().translationY(0f).setDuration(220).start()
    }

    private fun closeDrawer() {
        if (!drawerOpen) return
        drawerOpen = false
        hideKeyboard()
        search.setText("")
        drawer.animate()
            .translationY(resources.displayMetrics.heightPixels.toFloat())
            .setDuration(200)
            .withEndAction { if (!drawerOpen) drawer.visibility = View.GONE }
            .start()
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(search.windowToken, 0)
        search.clearFocus()
    }

    // ---------- Data ----------

    private fun loadApps() {
        val pm = packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = pm.queryIntentActivities(i, 0)
            .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.activityInfo.name, it.loadIcon(pm)) }
            .filter { it.pkg != packageName }
            .sortedBy { it.label.lowercase() }
        filter(search.text.toString())
        refreshDock()
    }

    private fun filter(q: String) {
        filtered = if (q.isBlank()) apps else apps.filter { it.label.contains(q.trim(), ignoreCase = true) }
        adapter.notifyDataSetChanged()
    }

    private fun launch(app: AppItem) {
        try {
            val it = Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER)
                .setClassName(app.pkg, app.cls)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            startActivity(it)
            closeDrawer()
        } catch (e: Exception) {
            toast("Не удалось открыть")
        }
    }

    private fun styled(d: Drawable): Drawable {
        val c = d.constantState?.newDrawable()?.mutate() ?: d.mutate()
        if (mono()) {
            val cm = ColorMatrix()
            cm.setSaturation(0f)
            c.setColorFilter(ColorMatrixColorFilter(cm))
        } else {
            c.clearColorFilter()
        }
        return c
    }

    // ---------- Dock ----------

    private fun defaultDock(): List<String> {
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_BROWSER),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        return intents.mapNotNull {
            packageManager.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        }.filter { it != "android" }.distinct()
    }

    private fun getDock(): List<String> =
        prefs.getString("dock", null)?.split(",")?.filter { it.isNotEmpty() } ?: defaultDock()

    private fun saveDock(list: List<String>) {
        prefs.edit().putString("dock", list.joinToString(",")).apply()
    }

    private fun refreshDock() {
        dock.removeAllViews()
        for (pkg in getDock()) {
            val app = apps.firstOrNull { it.pkg == pkg } ?: continue
            val iv = ImageView(this)
            iv.setImageDrawable(styled(app.icon))
            iv.setOnClickListener { launch(app) }
            iv.setOnLongClickListener {
                appMenu(app)
                true
            }
            dock.addView(iv, LinearLayout.LayoutParams(dp(48), dp(48)).apply {
                setMargins(dp(5), 0, dp(5), 0)
            })
        }
        dock.visibility = if (dock.childCount == 0) View.INVISIBLE else View.VISIBLE
    }

    // ---------- Menus ----------

    private fun appMenu(app: AppItem) {
        val inDock = getDock().contains(app.pkg)
        val items = arrayOf(
            if (inDock) "Убрать из дока" else "Добавить в док",
            "О приложении",
            "Удалить"
        )
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(app.label)
            .setItems(items) { _, which ->
                try {
                    when (which) {
                        0 -> {
                            val d = getDock().toMutableList()
                            if (inDock) {
                                d.remove(app.pkg)
                            } else if (d.size < 5) {
                                d.add(app.pkg)
                            } else {
                                toast("Док полный (макс. 5)")
                            }
                            saveDock(d)
                            refreshDock()
                        }
                        1 -> startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
                        )
                        2 -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
                        else -> {}
                    }
                } catch (e: Exception) {
                    toast("Ошибка")
                }
            }
            .show()
    }

    private fun homeMenu() {
        val items = arrayOf(
            "Монохромные иконки: " + (if (mono()) "ВКЛ" else "ВЫКЛ"),
            "Фон: " + (if (wall()) "ОБОИ" else "ЧЁРНЫЙ"),
            "Выбрать обои",
            "Лаунчер по умолчанию"
        )
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Nothing Launcher")
            .setItems(items) { _, which ->
                try {
                    when (which) {
                        0 -> {
                            prefs.edit().putBoolean("mono", !mono()).apply()
                            adapter.notifyDataSetChanged()
                            refreshDock()
                        }
                        1 -> {
                            prefs.edit().putBoolean("wall", !wall()).apply()
                            applyBg()
                        }
                        2 -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Обои"))
                        3 -> startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
                        else -> {}
                    }
                } catch (e: Exception) {
                    toast("Недоступно на этом устройстве")
                }
            }
            .show()
    }

    // ---------- Home info ----------

    private fun updateHome() {
        clock.invalidate()
        dateView.text = SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date()).uppercase()
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val s = SpannableString("● $pct%")
        s.setSpan(ForegroundColorSpan(nothingRed), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        batteryView.text = s
    }

    // ---------- Lifecycle ----------

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        closeDrawer()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (drawerOpen) closeDrawer()
        // лаунчер не закрывается кнопкой «назад»
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(pkgReceiver)
        } catch (e: Exception) {
        }
    }

    // ---------- Adapter ----------

    inner class AppAdapter : BaseAdapter() {
        override fun getCount() = filtered.size
        override fun getItem(position: Int): Any = filtered[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val item = filtered[position]
            val v = (convertView ?: makeCell()) as LinearLayout
            val iv = v.getChildAt(0) as ImageView
            val tv = v.getChildAt(1) as TextView
            iv.setImageDrawable(styled(item.icon))
            tv.text = item.label
            return v
        }

        private fun makeCell(): View {
            val l = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(0, dp(8), 0, dp(8))
            }
            l.addView(ImageView(this@MainActivity), LinearLayout.LayoutParams(dp(52), dp(52)))
            val tv = TextView(this@MainActivity).apply {
                setTextColor(Color.WHITE)
                textSize = 10f
                typeface = Typeface.MONOSPACE
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
                setPadding(dp(2), dp(6), dp(2), 0)
            }
            l.addView(tv, LinearLayout.LayoutParams(MATCH, WRAP))
            return l
        }
    }
}
