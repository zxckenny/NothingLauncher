package com.nothing.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.text.format.DateFormat
import android.view.View
import java.util.Calendar

/** Часы в стиле dot-matrix (как у Nothing). */
class DotClockView(ctx: Context) : View(ctx) {

    private val on = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val off = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#262626") }
    private val red = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#D71921") }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(w, (w / 25f * 7).toInt())
    }

    override fun onDraw(canvas: Canvas) {
        val cell = width / 25f
        val r = cell * 0.36f
        val is24 = DateFormat.is24HourFormat(context)
        val cal = Calendar.getInstance()
        var h = cal.get(if (is24) Calendar.HOUR_OF_DAY else Calendar.HOUR)
        if (!is24 && h == 0) h = 12
        val m = cal.get(Calendar.MINUTE)

        val glyphs = listOf(G[h / 10], G[h % 10], COLON, G[m / 10], G[m % 10])
        var col = 0
        for (g in glyphs) {
            val w = g[0].length
            for (row in 0 until 7) {
                for (cx in 0 until w) {
                    val lit = g[row][cx] == '1'
                    val p = if (!lit) off else if (g === COLON) red else on
                    canvas.drawCircle((col + cx + 0.5f) * cell, (row + 0.5f) * cell, r, p)
                }
            }
            col += w + 1
        }
    }

    companion object {
        private val COLON = arrayOf("0", "1", "0", "0", "0", "1", "0")
        private val G = arrayOf(
            arrayOf("01110", "10001", "10011", "10101", "11001", "10001", "01110"),
            arrayOf("00100", "01100", "00100", "00100", "00100", "00100", "01110"),
            arrayOf("01110", "10001", "00001", "00010", "00100", "01000", "11111"),
            arrayOf("11110", "00001", "00001", "01110", "00001", "00001", "11110"),
            arrayOf("00010", "00110", "01010", "10010", "11111", "00010", "00010"),
            arrayOf("11111", "10000", "11110", "00001", "00001", "10001", "01110"),
            arrayOf("00110", "01000", "10000", "11110", "10001", "10001", "01110"),
            arrayOf("11111", "00001", "00010", "00100", "01000", "01000", "01000"),
            arrayOf("01110", "10001", "10001", "01110", "10001", "10001", "01110"),
            arrayOf("01110", "10001", "10001", "01111", "00001", "00010", "01100")
        )
    }
}
